"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";

export default function Register() {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const router = useRouter(); // For navigation

	const register = async (e) => {
		e.preventDefault();
		try {
			await axios.post(
				"http://localhost:4000/api/auth/register",
				{
					email,
					password,
				},
				{
					withCredentials: true,
				}
			);
			alert("Registered! You can now login.");
			router.push("/login");
		} catch (err) {
			alert(err.response?.data?.message || "Registration error");
		}
	};

	return (
		<form onSubmit={register}>
			<h1>Register</h1>
			<input
				placeholder="Email"
				value={email}
				onChange={(e) => setEmail(e.target.value)}
			/>
			<input
				type="password"
				placeholder="Password"
				value={password}
				onChange={(e) => setPassword(e.target.value)}
			/>
			<button type="submit">Register</button>
		</form>
	);
}
