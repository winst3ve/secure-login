"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import axios from "axios";

export default function Login() {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const router = useRouter();

	const login = async (e) => {
		e.preventDefault();
		try {
			await axios.post(
				"http://localhost:4000/api/auth/login",
				{ email, password },
				{ withCredentials: true }
			);
			router.push("/dashboard");
		} catch (err) {
			alert(err.response?.data?.message || "Login error");
		}
	};

	return (
		<form onSubmit={login}>
			<h1>Login</h1>
			<input
				placeholder="Email"
				value={email}
				onChange={(e) => setEmail(e.target.value)}
			/>
			<input
				type="password"
				placeholder="Password"
				value={password}
				onChange={(e) => setPassword(e.target.value)}
			/>
			<button type="submit">Login</button>
		</form>
	);
}
